================================================================
  TLD Public MP v2.0
  Multiplayer + Performance + Dev Mode + Tooling for The Long Drive (Public)
================================================================

WHAT'S NEW vs v1.1
------------------
  * TLDPubMPPatch jumped 1.0 -> 2.9. v2.9 fixes the snap-on-exit
    bug (client now claims tosaveitemscript on car-enter so host's
    sim tracks our local sim while we drive). Also extends remote
    smoothing to non-car items, and ships ~13x outbound bandwidth
    reduction via the dedupe stack.
  * 6 new bundled plugins (perf, logging, capture, loopback,
    fake-id, spawner) — see list below.
  * TLDPubPerfPatch now bundled — runtime CPU/GC fixes.

WHAT IT DOES
------------
The public branch of The Long Drive ships with multiplayer code and
dev menu intact but hidden by scene-level toggles. This package
installs BepInEx 5 plus eleven plugins that flip the toggles back
on, stabilize the sync, and add diagnostic tooling.

Bundled plugins (each one is a separate DLL you can disable
individually via its config file in BepInEx/config/):

  TLDPubMPPatch    The main MP work — driver authority, claim-on-
                   drive (fixes exit-snap), per-message dedupes
                   (item pos/vel, request data, car floats /
                   ignition / gear, tank rate-limit), and the
                   smoothing lerp for remote cars + items.

  TLDPubPerfPatch  Runtime perf fixes — outline shader silenced,
                   audio-interior cache, FPS counter smoothing,
                   rear-light dirty-check (avoids per-frame
                   Material clones).

  TLDMPUnlock      Forces the Multiplayer button visible (was
                   hidden by mainScript2.disableMultiplayer=1).

  TLDPubDevMode    Forces the dev menu toggle on. Adds the cheat
                   panel + dev shortcuts:
                     CapsLock (short tap) -> toggle fly mode
                     F4  -> toggle TestObj
                     F8  -> spawn ragdoll
                     F3  -> debug action
                     End -> depth screenshot
                     0 / `~ -> respawn last spawn (not in car)

  TLDPubMPDiag     Off by default. Patches Steam P2P send/recv to
                   count packets by msgType. Enable in
                   com.reedo.tld.pubmpdiag.cfg.

  TLDDirectMP      Off by default. Direct-connect TCP fallback for
                   testing without Steam.

  TLDPubFullLog    Off by default. Emits a JSONL stream of game
                   state to BepInEx/fulllog/*.jsonl — snapshots,
                   spawns, removes. Pair with tld_log_tool.py to
                   diagnose desync.

  TLDPubMPCapture  Off by default. Captures all Steam P2P packets
                   to BepInEx/replays/*.tldreplay. Pair with
                   tld_replay_tool.py for offline analysis.

  TLDPubLoopback   Off by default. File-based packet bridge for
                   running two TLD instances locally without
                   internet. Set Mode=Host on one install, Mode=
                   Client on the other.

  TLDPubFakeId     Off by default. Overrides SteamUser.GetSteamID()
                   so two instances on one Steam account appear as
                   distinct users. Use with TLDPubLoopback.

  TLDPubSpawner    Off by default. F2 IMGUI overlay to spawn items
                   and buildings via mainscript.Spawn(). Only works
                   in scenes where the dev menu is also available.

  TLDPubMPUpdater  Patcher in BepInEx/patchers/. Each launch it
                   checks the GitHub manifest, downloads any newer
                   plugin DLLs to *.dll.update, then swaps them in
                   on the next launch.

INSTALL
-------
Linux:    ./install_linux.sh
Windows:  install_windows.bat (double-click)

The installer auto-detects standard Steam library paths. Pass a
custom path as the first argument if yours isn't on the list.
Existing BepInEx (e.g., from a beta install) is auto-backed-up to
.TLDPublicMP_backup_TIMESTAMP/ inside the install folder.

LINUX/PROTON ONLY: set this Steam launch option, or BepInEx will
silently not load:

   Steam -> right-click The Long Drive -> Properties ->
   Launch Options -> paste exactly:

       WINEDLLOVERRIDES="winhttp=n,b" %command%

Windows users do NOT need any launch option.

You only need to run the installer ONCE per machine; from then on,
the bundled updater keeps plugins current automatically.

KEY CONFIG (com.reedo.tld.pubmppatch.cfg)
-----------------------------------------
[Multiplayer]
ForceReliableSends = false   # leave OFF unless both ends same branch
DriverAuthority    = true    # don't let echoed inputs overwrite local driver
SyncBodyPush       = true    # broadcast body-collision pushes
ClaimDrivenCars    = true    # NEW in 2.9 — fixes exit-snap

[Smoothing]
SmoothRemoteCars   = true
SmoothRemoteItems  = true    # NEW in 2.9
SmoothDurationMs   = 250
SmoothMaxJumpMeters= 30

AUTO-UPDATES
------------
On every launch:
  1. Updater patcher runs in BepInEx's preloader phase.
  2. Applies any .dll.update files staged on the previous launch.
  3. Downloads the manifest:
       https://raw.githubusercontent.com/Reedo22/The-Long-Drive-Fixes/main/public-mp.txt
  4. Stages any newer DLLs as *.dll.update.
  5. Next launch, step 2 applies them.

To disable auto-update, edit:
  BepInEx/config/com.reedo.tld.pubmpupdater.cfg
  Set: AutoUpdate = false (or ManifestUrl = empty)

CROSS-VERSION PLAY
------------------
Lobbies are shared with the beta branch via Steam Matchmaking, so
cross-version play works for basic things but item interactions
(ragdolls, pushed objects, dropped items) will snap-back from a
beta host. Get both ends on this mod for clean sync.

If you're joining a beta host and feel "stuck" or unable to move,
leave ForceReliableSends=false. Beta expects high-frequency position
broadcasts on the Unreliable channel and silently drops them when
they arrive Reliable.

UNINSTALL
---------
Linux:    ./uninstall_linux.sh
Windows:  uninstall_windows.bat
Removes BepInEx + plugins + patcher. Backups in
.TLDPublicMP_backup_*/ are left alone — delete manually if not
needed.

TROUBLESHOOTING
---------------
Q: Multiplayer button still doesn't appear.
A: Check BepInEx/LogOutput.log for:
     [MPUnlock] forced menu.TBabfozelek.isOn = true
   If missing, BepInEx didn't start. On Linux/Proton, verify the
   WINEDLLOVERRIDES launch option is set. On Windows, verify
   winhttp.dll exists next to TheLongDrive.exe.

Q: Button appears but clicking it does nothing.
A: Look for "SteamManager.Initialized = True". If False, Steam
   isn't running, you're not logged in, or steam_appid.txt is
   missing.

Q: I can't move when joining a beta host.
A: Set ForceReliableSends=false in com.reedo.tld.pubmppatch.cfg.

Q: Car snaps back to host's position when I exit it.
A: Should be fixed in 2.9 (ClaimDrivenCars=true). If you still see
   this, check that the car was actually claimable (some scripted
   cars in tutorials may not be).

Q: Items / props look choppy when others push them.
A: Set SmoothRemoteItems=true in com.reedo.tld.pubmppatch.cfg.

Q: I don't want the dev menu.
A: Edit BepInEx/config/com.reedo.tld.pubdevmode.cfg, set
   Enabled = false. Or delete BepInEx/plugins/TLDPubDevMode.dll.

Q: How do I see what plugin versions I'm on?
A: Check BepInEx/LogOutput.log at startup. Each plugin logs its
   own name and version.

CREDITS
-------
BepInEx (https://github.com/BepInEx/BepInEx) - mod loader
HarmonyX - runtime method patching
The Long Drive - Genesz

LICENSE
-------
You may redistribute this installer. Modify at your own risk.
The game itself remains the developer's property and is not
included.
