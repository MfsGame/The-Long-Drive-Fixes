@echo off
REM TLD Public MP v1.1 - Windows installer
setlocal enabledelayedexpansion

set "SCRIPT_DIR=%~dp0"
set "SRC=%SCRIPT_DIR%files"

set "TARGET="
if not "%~1"=="" (
    set "TARGET=%~1"
) else (
    for %%P in (
        "%ProgramFiles(x86)%\Steam\steamapps\common\The Long Drive Public"
        "%ProgramFiles(x86)%\Steam\steamapps\common\The Long Drive"
        "C:\Program Files (x86)\Steam\steamapps\common\The Long Drive Public"
        "C:\Program Files (x86)\Steam\steamapps\common\The Long Drive"
        "D:\SteamLibrary\steamapps\common\The Long Drive Public"
        "D:\SteamLibrary\steamapps\common\The Long Drive"
        "E:\SteamLibrary\steamapps\common\The Long Drive Public"
        "E:\SteamLibrary\steamapps\common\The Long Drive"
    ) do (
        if exist "%%~P\TheLongDrive.exe" (
            set "TARGET=%%~P"
            goto :found
        )
    )
)
:found
if "%TARGET%"=="" goto :notfound
if not exist "%TARGET%\TheLongDrive.exe" goto :notfound

echo Installing into: %TARGET%
echo.

if exist "%TARGET%\winhttp.dll" goto :backup
if exist "%TARGET%\BepInEx"      goto :backup
goto :copyfiles

:backup
for /f "tokens=2-4 delims=/ " %%a in ('date /t') do set DSTAMP=%%c%%a%%b
for /f "tokens=1-2 delims=: " %%a in ('time /t') do set TSTAMP=%%a%%b
set "BACKUP=%TARGET%\.TLDPublicMP_backup_%DSTAMP%_%TSTAMP%"
echo Existing BepInEx detected - backing up to %BACKUP%
mkdir "%BACKUP%" 2>nul
if exist "%TARGET%\winhttp.dll"         copy /Y "%TARGET%\winhttp.dll"         "%BACKUP%\" >nul
if exist "%TARGET%\doorstop_config.ini" copy /Y "%TARGET%\doorstop_config.ini" "%BACKUP%\" >nul
if exist "%TARGET%\.doorstop_version"   copy /Y "%TARGET%\.doorstop_version"   "%BACKUP%\" >nul
if exist "%TARGET%\steam_appid.txt"     copy /Y "%TARGET%\steam_appid.txt"     "%BACKUP%\" >nul
if exist "%TARGET%\BepInEx"             xcopy /E /I /H /Y "%TARGET%\BepInEx"   "%BACKUP%\BepInEx" >nul

:copyfiles
echo Copying BepInEx framework + plugins + patcher...
copy /Y "%SRC%\winhttp.dll"          "%TARGET%\" >nul
copy /Y "%SRC%\doorstop_config.ini"  "%TARGET%\" >nul
copy /Y "%SRC%\.doorstop_version"    "%TARGET%\" >nul 2>nul
copy /Y "%SRC%\steam_appid.txt"      "%TARGET%\" >nul

if not exist "%TARGET%\BepInEx\core"     mkdir "%TARGET%\BepInEx\core"
if not exist "%TARGET%\BepInEx\plugins"  mkdir "%TARGET%\BepInEx\plugins"
if not exist "%TARGET%\BepInEx\patchers" mkdir "%TARGET%\BepInEx\patchers"
if not exist "%TARGET%\BepInEx\config"   mkdir "%TARGET%\BepInEx\config"

xcopy /E /Y "%SRC%\BepInEx\core\*"      "%TARGET%\BepInEx\core\" >nul
xcopy /Y    "%SRC%\BepInEx\plugins\*"   "%TARGET%\BepInEx\plugins\" >nul
xcopy /Y    "%SRC%\BepInEx\patchers\*"  "%TARGET%\BepInEx\patchers\" >nul

for %%C in ("%SRC%\BepInEx\config\*.cfg") do (
    if not exist "%TARGET%\BepInEx\config\%%~nxC" copy /Y "%%C" "%TARGET%\BepInEx\config\" >nul
)

echo.
echo ===============================================================
echo TLD Public MP v1.1 installed.
echo.
echo Launch The Long Drive (public branch) via Steam normally.
echo The Multiplayer button should appear on the main menu.
echo.
echo Auto-update is ON; checks github on every launch.
echo.
echo Bundled plugins:
echo   TLDMPUnlock     - re-enables the MP button
echo   TLDPubMPPatch   - ForceReliableSends + ForceMultiFlag
echo   TLDPubDevMode   - dev menu + CapsLock fly + F4/F8/F3/End
echo   TLDPubMPDiag    - packet diagnostic (off by default)
echo   TLDDirectMP     - direct-connect fallback (Mode=Off)
echo   TLDPubMPUpdater - github manifest updater
echo.
echo Logs: %TARGET%\BepInEx\LogOutput.log
echo Uninstall: uninstall_windows.bat
echo ===============================================================
pause
exit /b 0

:notfound
echo ERROR: could not find TLD install.
echo Pass the install path as the first argument, e.g.:
echo   install_windows.bat "C:\Games\The Long Drive"
pause
exit /b 1
