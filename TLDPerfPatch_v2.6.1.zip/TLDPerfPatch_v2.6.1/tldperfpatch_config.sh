#!/usr/bin/env bash
# TLD Performance Patch — Config Tool (Linux / Proton)
set -e

CANDIDATES=(
  "$HOME/.local/share/Steam/steamapps/common/The Long Drive"
  "$HOME/.steam/steam/steamapps/common/The Long Drive"
  "$HOME/.steam/root/steamapps/common/The Long Drive"
)
TLD_PATH=""
for p in "${CANDIDATES[@]}"; do
  [[ -f "$p/TheLongDrive.exe" ]] && TLD_PATH="$p" && break
done
[[ -z "$TLD_PATH" ]] && read -rp "Game folder: " TLD_PATH

CFG="$TLD_PATH/BepInEx/config/com.reedo.tld.perfpatch.cfg"
LOG="$TLD_PATH/BepInEx/LogOutput.log"

KEYS=(
  "OutlineGuard"
  "AnimatorHashCache"
  "FpsCounterSmoothing"
  "SkipSendsWhenDisconnected"
  "GetComponentCache"
  "ForceReliableSends"
)
DESCS=(
  "Outline error spam guard"
  "Animator string->hash cache"
  "FPS counter smoothing"
  "Skip MP Send methods when disconnected"
  "GetComponent within-frame caching"
  "Force reliable MP sends (desync fix)"
)

get_value() {
  grep -E "^$1\s*=" "$CFG" 2>/dev/null | awk -F '=' '{print $2}' | tr -d ' '
}

toggle_key() {
  local key="$1"
  local cur new
  cur=$(get_value "$key")
  if [[ "$cur" == "true" ]]; then new="false"; else new="true"; fi
  sed -i "s/^${key}\s*=.*/${key} = ${new}/" "$CFG"
  echo "  $key -> $new  (applied live)"
  sleep 0.5
}

while true; do
  clear
  echo
  echo "==============================================================="
  echo "  TLD Performance Patch — Config Tool"
  echo "==============================================================="
  echo "  Game folder: $TLD_PATH"
  echo
  if [[ ! -f "$CFG" ]]; then
    echo "  (config file not created yet — launch the game once first)"
    echo
    read -rp "q to quit, anything else to retry: " c
    [[ "$c" == "q" || "$c" == "Q" ]] && exit 0
    continue
  fi

  echo "  Toggleable patches (edits apply live, no restart needed):"
  echo
  for i in "${!KEYS[@]}"; do
    cur=$(get_value "${KEYS[$i]}")
    [[ -z "$cur" ]] && cur="?"
    printf "    %d. [%-5s] %s\n" "$((i+1))" "$cur" "${DESCS[$i]}"
  done
  echo
  echo "  Always-on patches (transpilers, restart required to remove):"
  echo "    - Material clone fixes in radio/rearlights/headlights"
  echo "    - Rigidbody ContinuousDynamic -> ContinuousSpeculative"
  echo
  echo "  e) Edit config file"
  echo "  l) View BepInEx log (last 50 lines)"
  echo "  q) Quit"
  echo
  read -rp "choice: " CHOICE
  case "$CHOICE" in
    [1-9]*)
      idx=$((CHOICE - 1))
      if (( idx >= 0 && idx < ${#KEYS[@]} )); then
        toggle_key "${KEYS[$idx]}"
      fi
      ;;
    e|E) "${EDITOR:-nano}" "$CFG" ;;
    l|L) [[ -f "$LOG" ]] && tail -n 50 "$LOG" ;;
    q|Q) exit 0 ;;
  esac
done
