@echo off
setlocal enabledelayedexpansion
title TLD Performance Patch - Config Tool

REM Find the game folder
set "TLD_PATH="
for %%P in (
  "C:\Program Files (x86)\Steam\steamapps\common\The Long Drive"
  "C:\Program Files\Steam\steamapps\common\The Long Drive"
  "C:\SteamLibrary\steamapps\common\The Long Drive"
  "D:\Steam\steamapps\common\The Long Drive"
  "D:\SteamLibrary\steamapps\common\The Long Drive"
  "E:\Steam\steamapps\common\The Long Drive"
  "E:\SteamLibrary\steamapps\common\The Long Drive"
  "F:\Steam\steamapps\common\The Long Drive"
  "F:\SteamLibrary\steamapps\common\The Long Drive"
) do (
  if exist "%%~P\TheLongDrive.exe" set "TLD_PATH=%%~P"
)
if not defined TLD_PATH (
  echo Could not find The Long Drive folder. Paste path:
  set /p "TLD_PATH=Path: "
)

set "CFG=%TLD_PATH%\BepInEx\config\com.reedo.tld.perfpatch.cfg"
set "LOG=%TLD_PATH%\BepInEx\LogOutput.log"

:menu
cls
echo.
echo ===============================================================
echo   TLD Performance Patch - Config Tool
echo ===============================================================
echo   Game folder: !TLD_PATH!
echo.

if not exist "%CFG%" (
  echo   ^(config file not created yet - launch the game once^)
  echo.
  echo   Q. Quit
  set /p "CHOICE=Choice: "
  if /i "!CHOICE!"=="Q" exit /b 0
  goto menu
)

echo   Toggleable patches ^(edits apply live, no restart needed^):
echo.
call :show 1 "OutlineGuard"              "Outline error spam guard"
call :show 2 "AnimatorHashCache"         "Animator string-^>hash cache"
call :show 3 "FpsCounterSmoothing"       "FPS counter smoothing"
call :show 4 "SkipSendsWhenDisconnected" "Skip MP Send methods when disconnected"
call :show 5 "GetComponentCache"         "GetComponent within-frame caching"
call :show 6 "ForceReliableSends"        "Force reliable MP sends ^(desync fix^)"
call :show 7 "AutoUpdate"                "Check for plugin updates on launch"
echo.
echo   World-gen tweaks (effects apply on game restart):
echo.
call :show 8 "TerrainAmplitudeScale"     "Terrain noise amplitude scale (1.0=vanilla, 0.5=flatter)"
call :show 9 "PoiMinDistanceFloor"       "Min distance between buildings/POIs (0=vanilla, try 30)"
call :show 0 "SuppressWorldGenLogs"      "Hide 'prefab hiba' / 'spawn error' log spam"
echo.
echo   Always-on patches ^(transpilers, restart required to remove^):
echo     - Material clone fixes in radio/rearlights/headlights
echo     - Rigidbody ContinuousDynamic -^> ContinuousSpeculative
echo.
if exist "!TLD_PATH!\BepInEx\plugins\TLDPerfPatch.update_pending" (
  echo   *** Update DOWNLOADED - restart game to apply ***
  echo.
)
echo   E. Edit config file in Notepad
echo   L. View latest BepInEx log
echo   U. Set update manifest URL ^(for friends-distribution^)
echo   Q. Quit
echo.
set /p "CHOICE=Choice (1-9/0 to toggle/edit, or letter): "

if "!CHOICE!"=="1" call :toggle "OutlineGuard"              & goto menu
if "!CHOICE!"=="2" call :toggle "AnimatorHashCache"         & goto menu
if "!CHOICE!"=="3" call :toggle "FpsCounterSmoothing"       & goto menu
if "!CHOICE!"=="4" call :toggle "SkipSendsWhenDisconnected" & goto menu
if "!CHOICE!"=="5" call :toggle "GetComponentCache"         & goto menu
if "!CHOICE!"=="6" call :toggle "ForceReliableSends"        & goto menu
if "!CHOICE!"=="7" call :toggle "AutoUpdate"                & goto menu
if "!CHOICE!"=="8" call :setfloat "TerrainAmplitudeScale" "Terrain noise amplitude scale (1.0=vanilla, 0.5=flatter)" & goto menu
if "!CHOICE!"=="9" call :setfloat "PoiMinDistanceFloor" "Min distance between buildings/POIs in meters (0=vanilla, try 30)" & goto menu
if "!CHOICE!"=="0" call :toggle "SuppressWorldGenLogs"      & goto menu
if /i "!CHOICE!"=="U" call :seturl & goto menu
if /i "!CHOICE!"=="E" notepad "%CFG%" & goto menu
if /i "!CHOICE!"=="L" notepad "%LOG%" & goto menu
if /i "!CHOICE!"=="Q" exit /b 0
goto menu

:seturl
echo.
echo Current UpdateManifestUrl:
for /f "tokens=1,* delims==" %%A in ('findstr /B "UpdateManifestUrl" "%CFG%" 2^>nul') do (
  echo   %%~B
)
echo.
echo Paste the URL of your update manifest. Manifest format:
echo   Line 1: version string ^(e.g. 2.4.0^)
echo   Line 2: direct download URL for TLDPerfPatch.dll
echo.
echo Press Enter with no input to keep the current value.
set /p "NEWURL=URL: "
if "!NEWURL!"=="" goto :eof
powershell -NoProfile -Command "(Get-Content -Raw -Path '%CFG%') -replace '(?m)^UpdateManifestUrl\s*=.*', 'UpdateManifestUrl = !NEWURL!' | Set-Content -NoNewline -Path '%CFG%'"
echo   UpdateManifestUrl -^> !NEWURL!
timeout /t 1 /nobreak >nul
goto :eof

:setfloat
REM Args: %1 = key, %2 = description
set "KEY=%~1"
for /f "tokens=1,2 delims==" %%A in ('findstr /B "!KEY!" "%CFG%" 2^^>nul') do (
  set "CUR=%%~B"
)
echo.
echo %~2
echo Current value: !CUR!
set /p "NEWVAL=Enter new value (blank to keep): "
if "!NEWVAL!"=="" goto :eof
powershell -NoProfile -Command "(Get-Content -Raw -Path '%CFG%') -replace '(?m)^!KEY!\s*=.*', '!KEY! = !NEWVAL!' | Set-Content -NoNewline -Path '%CFG%'"
echo.
echo   !KEY! -^> !NEWVAL!
timeout /t 1 /nobreak >nul
goto :eof

:show
REM Args: %1 = number, %2 = setting key, %3 = description
set "CUR=?"
for /f "tokens=1,2 delims==" %%A in ('findstr /B %2 "%CFG%" 2^>nul') do (
  set "RAW=%%~B"
  set "RAW=!RAW: =!"
  set "CUR=!RAW!"
)
echo     %1. [!CUR!] %~3
goto :eof

:toggle
REM Args: %1 = setting key. Flip true^<-^>false using PowerShell.
set "KEY=%~1"
set "CUR="
for /f "tokens=1,2 delims==" %%A in ('findstr /B "%KEY%" "%CFG%"') do (
  set "RAW=%%~B"
  set "RAW=!RAW: =!"
  set "CUR=!RAW!"
)
if /i "!CUR!"=="true" ( set "NEW=false" ) else ( set "NEW=true" )
powershell -NoProfile -Command "(Get-Content -Raw -Path '%CFG%') -replace '(?m)^%KEY%\s*=\s*\w+', '%KEY% = !NEW!' | Set-Content -NoNewline -Path '%CFG%'"
echo.
echo   %KEY% -^> !NEW!  ^(applied live^)
timeout /t 1 /nobreak >nul
goto :eof
