#!/usr/bin/env bash
set -e
echo "TLD Performance Patch — uninstaller"
CANDIDATES=(
  "$HOME/.local/share/Steam/steamapps/common/The Long Drive"
  "$HOME/.steam/steam/steamapps/common/The Long Drive"
)
TLD_PATH=""
for p in "${CANDIDATES[@]}"; do
  [[ -f "$p/TheLongDrive.exe" ]] && TLD_PATH="$p" && break
done
if [[ -z "$TLD_PATH" ]]; then read -rp "Game folder: " TLD_PATH; fi
[[ -f "$TLD_PATH/TheLongDrive.exe" ]] || { echo "Not found at $TLD_PATH"; exit 1; }
rm -f "$TLD_PATH/BepInEx/plugins/TLDPerfPatch.dll"
read -rp "Also remove BepInEx itself? (y/N): " full
if [[ "$full" == "y" || "$full" == "Y" ]]; then
  rm -f "$TLD_PATH/winhttp.dll" "$TLD_PATH/doorstop_config.ini" "$TLD_PATH/.doorstop_version"
  rm -rf "$TLD_PATH/BepInEx"
fi
echo "Done. Don't forget to remove the WINEDLLOVERRIDES launch option in Steam."
