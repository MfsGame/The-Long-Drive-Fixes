@echo off
setlocal enabledelayedexpansion
title TLD Performance Patch v1.9 - Uninstaller

echo.
echo ===============================================================
echo   TLD Performance Patch v1.9 - Uninstaller
echo ===============================================================
echo.
echo This will REMOVE the patch from your The Long Drive folder.
echo Other BepInEx plugins (if you have any) will be preserved.
echo.
pause

set "TLD_PATH="
for %%P in (
  "C:\Program Files (x86)\Steam\steamapps\common\The Long Drive"
  "C:\Program Files\Steam\steamapps\common\The Long Drive"
  "C:\SteamLibrary\steamapps\common\The Long Drive"
  "D:\Steam\steamapps\common\The Long Drive"
  "D:\SteamLibrary\steamapps\common\The Long Drive"
  "E:\Steam\steamapps\common\The Long Drive"
  "E:\SteamLibrary\steamapps\common\The Long Drive"
  "F:\Steam\steamapps\common\The Long Drive"
  "F:\SteamLibrary\steamapps\common\The Long Drive"
) do (
  if exist "%%~P\TheLongDrive.exe" set "TLD_PATH=%%~P"
)

if defined TLD_PATH (
  echo Found game folder: !TLD_PATH!
) else (
  echo Could not auto-detect game folder.
  set /p "TLD_PATH=Paste the full path here (no quotes): "
)

if not exist "!TLD_PATH!\TheLongDrive.exe" (
  echo ERROR: TheLongDrive.exe not found at: !TLD_PATH!
  pause
  exit /b 1
)

echo.
echo Removing TLD Performance Patch plugin only...
if exist "!TLD_PATH!\BepInEx\plugins\TLDPerfPatch.dll" del /Q "!TLD_PATH!\BepInEx\plugins\TLDPerfPatch.dll"

echo.
set /p "FULL=Also remove BepInEx itself? (Y/N, choose N if you use other BepInEx mods): "
if /i "!FULL!"=="Y" (
  echo Removing all BepInEx files...
  if exist "!TLD_PATH!\winhttp.dll" del /Q "!TLD_PATH!\winhttp.dll"
  if exist "!TLD_PATH!\doorstop_config.ini" del /Q "!TLD_PATH!\doorstop_config.ini"
  if exist "!TLD_PATH!\.doorstop_version" del /Q "!TLD_PATH!\.doorstop_version"
  if exist "!TLD_PATH!\BepInEx" rmdir /S /Q "!TLD_PATH!\BepInEx"
)

echo.
echo Uninstallation complete.
echo.
pause
exit /b 0
