@echo off
REM Launcher for the cross-platform Python GUI. Tries common Python commands.

where py >nul 2>&1
if %errorlevel%==0 (
  py "%~dp0tldperfpatch_gui.py"
  goto :eof
)

where python >nul 2>&1
if %errorlevel%==0 (
  python "%~dp0tldperfpatch_gui.py"
  goto :eof
)

where python3 >nul 2>&1
if %errorlevel%==0 (
  python3 "%~dp0tldperfpatch_gui.py"
  goto :eof
)

echo.
echo Python is not installed.
echo.
echo Install it from https://www.python.org/downloads/
echo (Make sure to check "Add Python to PATH" during install.)
echo.
echo As a fallback, you can use tldperfpatch_config.bat instead
echo for a text-based menu in this terminal.
echo.
pause
