#!/usr/bin/env python3
"""
TLD Performance Patch — Config GUI

Cross-platform standalone configuration tool. Uses only the Python standard library
(tkinter). Reads and writes the BepInEx config file directly.

Usage:
    python3 tldperfpatch_gui.py     (Linux / macOS)
    python tldperfpatch_gui.py      (Windows)

Or double-click on Windows if .py is associated with Python.
"""

import os
import re
import sys
import platform
from pathlib import Path

try:
    import tkinter as tk
    from tkinter import ttk, messagebox, filedialog
except ImportError:
    print("ERROR: tkinter is not installed.")
    print("On Linux: sudo apt install python3-tk")
    print("On Windows: tkinter comes with the standard Python installer from python.org")
    sys.exit(1)


PLUGIN_GUID = "com.reedo.tld.perfpatch"
APP_TITLE = "TLD Performance Patch — Config"


# ----- locate the game folder ------------------------------------------------

def candidate_paths():
    sys_name = platform.system()
    home = Path.home()
    if sys_name == "Windows":
        drives = ["C:", "D:", "E:", "F:"]
        for d in drives:
            for stem in [
                f"{d}/Program Files (x86)/Steam/steamapps/common/The Long Drive",
                f"{d}/Program Files/Steam/steamapps/common/The Long Drive",
                f"{d}/Steam/steamapps/common/The Long Drive",
                f"{d}/SteamLibrary/steamapps/common/The Long Drive",
            ]:
                yield Path(stem)
    else:
        for stem in [
            home / ".local/share/Steam/steamapps/common/The Long Drive",
            home / ".steam/steam/steamapps/common/The Long Drive",
            home / ".steam/root/steamapps/common/The Long Drive",
        ]:
            yield stem


def find_game_folder():
    for c in candidate_paths():
        if (c / "TheLongDrive.exe").exists():
            return c
    return None


# ----- BepInEx config parser -------------------------------------------------
#
# Reads/writes the .cfg format BepInEx uses. Roughly:
#
#   ## comment (description)
#   # Setting type: Boolean
#   # Default value: true
#   Key = value
#
# We parse type from the "# Setting type: X" line so we can render the right widget.


class CfgEntry:
    def __init__(self, section, key, value, type_name, default, description, raw_index):
        self.section = section
        self.key = key
        self.value = value
        self.type_name = type_name
        self.default = default
        self.description = description
        self.raw_index = raw_index  # line index where the "Key = value" line lives

    def __repr__(self):
        return f"<{self.section}.{self.key}: {self.type_name} = {self.value}>"


def parse_cfg(path):
    lines = path.read_text(encoding="utf-8").splitlines()
    entries = []
    current_section = ""
    last_desc = ""
    last_type = ""
    last_default = ""
    for i, line in enumerate(lines):
        s = line.strip()
        if not s:
            continue
        if s.startswith("[") and s.endswith("]"):
            current_section = s[1:-1]
            last_desc = ""
            last_type = ""
            last_default = ""
            continue
        if s.startswith("##"):
            text = s[2:].strip()
            last_desc = (last_desc + " " + text).strip() if last_desc else text
            continue
        if s.startswith("#"):
            text = s[1:].strip()
            m = re.match(r"Setting type:\s*(.+)$", text)
            if m: last_type = m.group(1).strip()
            m = re.match(r"Default value:\s*(.*)$", text)
            if m: last_default = m.group(1).strip()
            continue
        m = re.match(r"^([A-Za-z_][A-Za-z0-9_]*)\s*=\s*(.*)$", s)
        if m:
            entries.append(CfgEntry(
                section=current_section,
                key=m.group(1),
                value=m.group(2).strip(),
                type_name=last_type,
                default=last_default,
                description=last_desc,
                raw_index=i,
            ))
            last_desc = ""
            last_type = ""
            last_default = ""
    return lines, entries


def write_value(lines, entry, new_value):
    """Update a single line in-place."""
    lines[entry.raw_index] = f"{entry.key} = {new_value}"


# ----- GUI -------------------------------------------------------------------

class ConfigGUI:
    def __init__(self, root, game_path):
        self.root = root
        self.game_path = game_path
        self.cfg_path = game_path / "BepInEx" / "config" / f"{PLUGIN_GUID}.cfg"
        self.lines = []
        self.entries = []
        self.widgets = {}  # (section, key) -> tk variable
        self.dirty = False

        root.title(APP_TITLE)
        root.geometry("740x680")

        self._build_topbar()
        self._build_status()
        if not self.cfg_path.exists():
            self.show_no_cfg()
        else:
            self.load_and_render()

    def _build_topbar(self):
        top = ttk.Frame(self.root, padding=8)
        top.pack(fill=tk.X)
        ttk.Label(top, text=f"Game folder: {self.game_path}", font=("TkDefaultFont", 9)).pack(side=tk.LEFT)
        ttk.Button(top, text="Reload", command=self.load_and_render).pack(side=tk.RIGHT, padx=4)
        ttk.Button(top, text="Save", command=self.save).pack(side=tk.RIGHT, padx=4)
        ttk.Button(top, text="Open cfg in editor", command=self.open_external).pack(side=tk.RIGHT, padx=4)

    def _build_status(self):
        self.status_var = tk.StringVar(value="")
        bar = ttk.Frame(self.root, padding=(8, 0))
        bar.pack(fill=tk.X)
        ttk.Label(bar, textvariable=self.status_var, foreground="#555").pack(side=tk.LEFT)

    def set_status(self, msg, color="#555"):
        self.status_var.set(msg)

    def show_no_cfg(self):
        msg = ttk.Frame(self.root, padding=16)
        msg.pack(expand=True, fill=tk.BOTH)
        ttk.Label(msg, text="Config file not found.", font=("TkDefaultFont", 11, "bold")).pack(pady=(20, 8))
        ttk.Label(msg, text=str(self.cfg_path), foreground="#666").pack()
        ttk.Label(msg, text=(
            "\nLaunch The Long Drive once with the plugin installed so BepInEx "
            "generates the config file, then come back and reload."
        ), wraplength=600).pack(pady=20)
        ttk.Button(msg, text="Reload", command=self._reload_check).pack(pady=10)

    def _reload_check(self):
        if self.cfg_path.exists():
            for w in self.root.winfo_children():
                w.destroy()
            self.__init__(self.root, self.game_path)
        else:
            messagebox.showinfo(APP_TITLE, "Config file still doesn't exist. Run the game once first.")

    def load_and_render(self):
        # Wipe any existing scroll content
        for w in self.root.winfo_children():
            if isinstance(w, ttk.Frame) and getattr(w, "_is_scroll_container", False):
                w.destroy()

        self.lines, self.entries = parse_cfg(self.cfg_path)
        self.widgets = {}
        self.dirty = False

        container = ttk.Frame(self.root)
        container._is_scroll_container = True
        container.pack(fill=tk.BOTH, expand=True, padx=8, pady=4)

        canvas = tk.Canvas(container, borderwidth=0, highlightthickness=0)
        scroll = ttk.Scrollbar(container, orient=tk.VERTICAL, command=canvas.yview)
        inner = ttk.Frame(canvas)
        inner.bind("<Configure>", lambda e: canvas.configure(scrollregion=canvas.bbox("all")))
        canvas.create_window((0, 0), window=inner, anchor="nw")
        canvas.configure(yscrollcommand=scroll.set)
        canvas.pack(side=tk.LEFT, fill=tk.BOTH, expand=True)
        scroll.pack(side=tk.RIGHT, fill=tk.Y)

        # bind mousewheel
        def _on_mw(event):
            canvas.yview_scroll(int(-1 * (event.delta / 120)), "units")
        canvas.bind_all("<MouseWheel>", _on_mw)
        canvas.bind_all("<Button-4>", lambda e: canvas.yview_scroll(-3, "units"))
        canvas.bind_all("<Button-5>", lambda e: canvas.yview_scroll(3, "units"))

        # Group by section
        by_section = {}
        for e in self.entries:
            by_section.setdefault(e.section, []).append(e)

        for section in sorted(by_section.keys()):
            sec_frame = ttk.LabelFrame(inner, text=section, padding=10)
            sec_frame.pack(fill=tk.X, padx=4, pady=6)
            for e in by_section[section]:
                self._render_entry(sec_frame, e)

        self.set_status(f"Loaded {len(self.entries)} settings from {self.cfg_path.name}")

    def _render_entry(self, parent, entry):
        row = ttk.Frame(parent)
        row.pack(fill=tk.X, pady=4)

        # Key + widget
        top = ttk.Frame(row)
        top.pack(fill=tk.X)
        ttk.Label(top, text=entry.key, width=28, anchor=tk.W,
                  font=("TkDefaultFont", 10, "bold")).pack(side=tk.LEFT)

        widget_holder = ttk.Frame(top)
        widget_holder.pack(side=tk.LEFT, fill=tk.X, expand=True)

        if entry.type_name == "Boolean":
            var = tk.BooleanVar(value=entry.value.strip().lower() == "true")
            cb = ttk.Checkbutton(widget_holder, variable=var,
                                  text="(enabled)" if var.get() else "(disabled)",
                                  command=lambda: self._on_change(entry, var))
            cb.pack(side=tk.LEFT)
            def update_label(*_):
                cb.configure(text="(enabled)" if var.get() else "(disabled)")
            var.trace_add("write", update_label)
            self.widgets[(entry.section, entry.key)] = ("bool", var)
        elif entry.type_name in ("Single", "Double", "Int32", "Int64"):
            var = tk.StringVar(value=entry.value)
            ent = ttk.Entry(widget_holder, textvariable=var, width=12)
            ent.pack(side=tk.LEFT)
            var.trace_add("write", lambda *_: self._on_change(entry, var))
            self.widgets[(entry.section, entry.key)] = ("number", var)
        else:  # String / KeyboardShortcut / unknown
            var = tk.StringVar(value=entry.value)
            ent = ttk.Entry(widget_holder, textvariable=var)
            ent.pack(side=tk.LEFT, fill=tk.X, expand=True)
            var.trace_add("write", lambda *_: self._on_change(entry, var))
            self.widgets[(entry.section, entry.key)] = ("string", var)

        ttk.Label(top, text=f"[{entry.type_name or '?'}]",
                  foreground="#888", font=("TkDefaultFont", 8)).pack(side=tk.RIGHT)

        # Description
        if entry.description:
            ttk.Label(row, text=entry.description, foreground="#555",
                      wraplength=680, justify=tk.LEFT,
                      font=("TkDefaultFont", 9)).pack(fill=tk.X, padx=(0, 0), pady=(2, 0))

    def _on_change(self, entry, var):
        self.dirty = True
        self.set_status(f"Modified {entry.section}.{entry.key} — click Save to write.")

    def save(self):
        for entry in self.entries:
            kind, var = self.widgets.get((entry.section, entry.key), (None, None))
            if var is None: continue
            if kind == "bool":
                new_val = "true" if var.get() else "false"
            else:
                new_val = str(var.get()).strip()
            write_value(self.lines, entry, new_val)
        text = "\n".join(self.lines)
        # Preserve trailing newline if it was there
        if not text.endswith("\n"):
            text += "\n"
        self.cfg_path.write_text(text, encoding="utf-8")
        self.dirty = False
        self.set_status(f"Saved {self.cfg_path.name}. BepInEx will pick up the change live if the game is running.")

    def open_external(self):
        sys_name = platform.system()
        if sys_name == "Windows":
            os.startfile(str(self.cfg_path))
        elif sys_name == "Darwin":
            os.system(f'open "{self.cfg_path}"')
        else:
            os.system(f'xdg-open "{self.cfg_path}"')


def main():
    root = tk.Tk()
    game = find_game_folder()
    if game is None:
        root.withdraw()
        messagebox.showerror(APP_TITLE,
                             "Could not find your The Long Drive folder.\n\n"
                             "You'll be asked to pick it.")
        chosen = filedialog.askdirectory(title="Select The Long Drive game folder")
        if not chosen:
            return
        game = Path(chosen)
        if not (game / "TheLongDrive.exe").exists():
            messagebox.showerror(APP_TITLE, f"TheLongDrive.exe not found in {game}")
            return
        root.deiconify()

    ConfigGUI(root, game)
    root.mainloop()


if __name__ == "__main__":
    main()
