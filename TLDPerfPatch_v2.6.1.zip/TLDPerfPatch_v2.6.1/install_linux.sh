#!/usr/bin/env bash
# TLD Performance Patch v2.6.1 — Linux/Proton installer
set -e

echo
echo "==============================================================="
echo "  TLD Performance Patch v2.6.1 — Linux/Proton Installer"
echo "==============================================================="
echo

# Find game folder
CANDIDATES=(
  "$HOME/.local/share/Steam/steamapps/common/The Long Drive"
  "$HOME/.steam/steam/steamapps/common/The Long Drive"
  "$HOME/.steam/root/steamapps/common/The Long Drive"
  "/run/media/$USER/*/SteamLibrary/steamapps/common/The Long Drive"
)
TLD_PATH=""
for p in "${CANDIDATES[@]}"; do
  for expanded in $p; do
    if [[ -f "$expanded/TheLongDrive.exe" ]]; then
      TLD_PATH="$expanded"
      break 2
    fi
  done
done

if [[ -z "$TLD_PATH" ]]; then
  echo "Could not auto-detect The Long Drive folder."
  read -rp "Paste the full path here: " TLD_PATH
fi

if [[ ! -f "$TLD_PATH/TheLongDrive.exe" ]]; then
  echo "ERROR: TheLongDrive.exe not found at: $TLD_PATH"
  exit 1
fi

echo "Installing to: $TLD_PATH"
echo

# Copy
mkdir -p "$TLD_PATH/BepInEx/plugins" "$TLD_PATH/BepInEx/config"
cp -r files/BepInEx/core "$TLD_PATH/BepInEx/"
cp files/BepInEx/plugins/TLDPerfPatch.dll "$TLD_PATH/BepInEx/plugins/"
mkdir -p "$TLD_PATH/BepInEx/patchers"
cp files/BepInEx/patchers/TLDPerfPatchUpdater.dll "$TLD_PATH/BepInEx/patchers/"
cp files/winhttp.dll "$TLD_PATH/winhttp.dll"
cp files/doorstop_config.ini "$TLD_PATH/doorstop_config.ini"
cp files/.doorstop_version "$TLD_PATH/.doorstop_version"
cp tldperfpatch_config.sh "$TLD_PATH/tldperfpatch_config.sh"
chmod +x "$TLD_PATH/tldperfpatch_config.sh"

echo "Files copied."
echo
echo "The config tool is now in your game folder at:"
echo "    $TLD_PATH/tldperfpatch_config.sh"
echo "Run it any time you want to toggle the one runtime option."
echo
echo "==============================================================="
echo "  REQUIRED — Steam launch option for Linux/Proton"
echo "==============================================================="
echo
echo "Steam -> right-click The Long Drive -> Properties ->"
echo "Launch Options -> paste exactly:"
echo
echo "    WINEDLLOVERRIDES=\"winhttp=n,b\" %command%"
echo
echo "Without this, BepInEx will NOT load on Linux/Proton."
echo
echo "To verify after launching the game:"
echo "    tail -f \"$TLD_PATH/BepInEx/LogOutput.log\""
echo
echo "Done."
