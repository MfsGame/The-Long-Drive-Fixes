@echo off
setlocal enabledelayedexpansion
title TLD Performance Patch v1.9 - Installer

echo.
echo ===============================================================
echo   TLD Performance Patch v1.9 - Windows Installer
echo ===============================================================
echo.
echo This will install a runtime perf mod into your The Long Drive
echo folder. It does not modify any game files on disk - the mod
echo loads via BepInEx and patches code at runtime.
echo.
pause

REM ---------- 1. Find the game folder ----------
set "TLD_PATH="
for %%P in (
  "C:\Program Files (x86)\Steam\steamapps\common\The Long Drive"
  "C:\Program Files\Steam\steamapps\common\The Long Drive"
  "C:\SteamLibrary\steamapps\common\The Long Drive"
  "D:\Steam\steamapps\common\The Long Drive"
  "D:\SteamLibrary\steamapps\common\The Long Drive"
  "E:\Steam\steamapps\common\The Long Drive"
  "E:\SteamLibrary\steamapps\common\The Long Drive"
  "F:\Steam\steamapps\common\The Long Drive"
  "F:\SteamLibrary\steamapps\common\The Long Drive"
) do (
  if exist "%%~P\TheLongDrive.exe" set "TLD_PATH=%%~P"
)

if defined TLD_PATH (
  echo Found game folder: !TLD_PATH!
) else (
  echo.
  echo Could not auto-detect your The Long Drive folder.
  echo.
  echo You can find it via Steam:
  echo   Right-click The Long Drive ^> Manage ^> Browse local files
  echo.
  set /p "TLD_PATH=Paste the full path here (no quotes): "
)

if not exist "!TLD_PATH!\TheLongDrive.exe" (
  echo.
  echo ERROR: TheLongDrive.exe not found at:
  echo   !TLD_PATH!
  echo Please run this installer again with the correct path.
  echo.
  pause
  exit /b 1
)

echo.
echo Installing to: !TLD_PATH!
echo.

REM ---------- 2. Warn if BepInEx already exists ----------
if exist "!TLD_PATH!\BepInEx\plugins" (
  echo NOTE: BepInEx is already installed at this location.
  echo Existing plugins will be preserved; only the TLD perf
  echo plugin and core BepInEx files will be overwritten.
  echo.
  set /p "CONT=Continue? (Y/N): "
  if /i not "!CONT!"=="Y" (
    echo Aborted.
    pause
    exit /b 0
  )
)

REM ---------- 3. Copy files ----------
echo Copying BepInEx core...
xcopy /E /Y /I /Q "files\BepInEx\core" "!TLD_PATH!\BepInEx\core" >nul
if errorlevel 1 goto :error

echo Copying plugin...
if not exist "!TLD_PATH!\BepInEx\plugins" mkdir "!TLD_PATH!\BepInEx\plugins"
copy /Y "files\BepInEx\plugins\TLDPerfPatch.dll" "!TLD_PATH!\BepInEx\plugins\TLDPerfPatch.dll" >nul
if errorlevel 1 goto :error

echo Copying update patcher...
if not exist "!TLD_PATH!\BepInEx\patchers" mkdir "!TLD_PATH!\BepInEx\patchers"
copy /Y "files\BepInEx\patchers\TLDPerfPatchUpdater.dll" "!TLD_PATH!\BepInEx\patchers\TLDPerfPatchUpdater.dll" >nul
if errorlevel 1 goto :error

echo Creating config folder...
if not exist "!TLD_PATH!\BepInEx\config" mkdir "!TLD_PATH!\BepInEx\config"

echo Copying doorstop loader...
copy /Y "files\winhttp.dll" "!TLD_PATH!\winhttp.dll" >nul
if errorlevel 1 goto :error
copy /Y "files\doorstop_config.ini" "!TLD_PATH!\doorstop_config.ini" >nul
copy /Y "files\.doorstop_version" "!TLD_PATH!\.doorstop_version" >nul

echo Copying config tool...
copy /Y "tldperfpatch_config.bat" "!TLD_PATH!\tldperfpatch_config.bat" >nul

echo.
echo ===============================================================
echo   Installation complete!
echo ===============================================================
echo.
echo You can now launch The Long Drive normally. BepInEx will load
echo automatically on Windows - no launch option needed.
echo.
echo The 42 always-on patches will apply silently every time you
echo launch the game. You do NOT need to run anything else.
echo.
echo If you ever want to toggle "Force reliable MP sends" (the one
echo runtime option, for fixing position desync in multiplayer):
echo   1. Open your game folder via Steam: right-click The Long
echo      Drive ^> Manage ^> Browse local files
echo   2. Double-click "tldperfpatch_config.bat"
echo.
echo To verify the patch loaded after launching the game, open:
echo   !TLD_PATH!\BepInEx\LogOutput.log
echo and look for "TLD Performance Patch v2.6.1 loaded."
echo.
echo To uninstall: run uninstall_windows.bat.
echo.
pause
exit /b 0

:error
echo.
echo ERROR copying files. The installer may need to be run as
echo Administrator if your game is in Program Files.
echo.
pause
exit /b 1
